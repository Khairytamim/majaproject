<div class="container" style="margin-top: 3%">
   <div class="row">
     	<div class="col s3 l3">
                    <div class="col s12" style="word-break: break-all; hyphens: auto;">
                        <img src="<?php echo base_url();?>assets/img/logo_brand_mini/<?php echo $id_too;?>.jpg" style="width:100px; margin-left:auto; margin-right:auto" onerror="this.src='<?php echo base_url();?>assets/img/logo_brand/coollike.png'">
                    </div>
                    <div class="col s12" style="word-break: break-all; hyphens: auto;">
                        <h6><b><?php echo $nama_user;?></b></h6>
                    </div>
                
                <div class="col s10.5" style="word-break: break-all; hyphens: auto;">
	                <p><i class="material-icons">store</i> <b>Brand Saya</b></p>
	                <p><a href="<?php echo base_url();?>adminDistro/pengaturan_toko" class="collection-item">Pengaturan Brand</a></p>
	                <p><a href="<?php echo base_url();?>adminDistro/pesan">Pesan</a></p>
	                
	                <p style="margin-top: 30px"><i class="material-icons">shopping_basket</i> <b>Produk Saya</b></p>
	                <p><a href="<?php echo base_url();?>AdminDistro/daftar_produk" class="collection-item">Daftar Produk</a></p>
	                <!-- p><a href="<?php echo base_url();?>AdminDistro/tambah_produk" class="collection-item">Tambah Produk</a></p -->
	                
	                <p style="margin-top: 30px"><i class="material-icons">call_split</i> <b>Toko Saya</b></p>
	                <p><a href="<?php echo base_url();?>AdminDistro/daftar_cabang" class="collection-item" class="collection-item">Daftar Toko</a></p>
	                <p><a href="<?php echo base_url();?>AdminDistro/tambah_cabang" class="collection-item" class="collection-item">Tambah Toko</a></p>
	       </div>

       </div>