<html>
<head>
<link rel="stylesheet" type="text/css" href="assets/css/system_grid.css">
</head>
<body>
<div class="row">
	<div class="col s1">
	<p>  </p>
	</div>
	<div class ="col s8" style="padding-top:20px">
		<H4>LIAT EVENT</H4>
		<div style="display:block; width: 20%; height: 2px; background-color: black; margin-left: 0px;"></div><br>
		<!-- download apss on google-->
			<div>
				<img src="<?php echo base_url();?>assets/img/bannergoogle.jpg" style="width:100%; height:100%">
			 </div>


		<!-- banner event-->
			<div>
				<img src="<?php echo base_url();?>assets/img/banner1.jpg" style="width:100%; height:100%">
			 </div>

		<!-- banner event2-->
			<div>
				<img src="<?php echo base_url();?>assets/img/banner2.jpg" style="width:100%; height:100%">
			 </div>


		<!-- banner event 3-->
			<div>
				<img src="<?php echo base_url();?>assets/img/banner3.jpg" style="width:100%; height:100%">
			 </div>
			 
		<!-- banner event 4-->
			<div>
				<img src="<?php echo base_url();?>assets/img/banner1.jpg" style="width:100%; height:100%">
			 </div>

	</div>
	<div class="col s3"style="margin-top:130px"><center>
		<div style="margin-bottom: 20px">
				<img src="<?php echo base_url();?>assets/img/tee1.jpg" style="width:60%; height: 60%">
			 </div>
		<div style="margin-bottom: 20px">
				<img src="<?php echo base_url();?>assets/img/tee2.jpg" style="width:60%; height: 60%">
			 </div>
		<div style="margin-bottom: 20px">
				<img src="<?php echo base_url();?>assets/img/tee3.jpg" style="width:60%; height: 60%">
		</div>
		</center>
	</div>
</div>

</body>
</html>
