  <footer style="color: dimgray; background-color: #e0e0e0; height: 40px; width: 100%; padding: 10px; position: fixed; bottom: 0;">
      <div class="container" style="font-size: 11pt; text-align: center"><b>seveid.com</b> | admin@seveid.com</div>
  </footer>
</body>
</html>