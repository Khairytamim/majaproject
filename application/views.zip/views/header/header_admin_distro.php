<!DOCTYPE html>
<html>
<head>
	 <meta name="google-site-verification" content="iXeuDSWh4LPaiEFS54cAl5IWL1JyGEuqh-KAXFRFH_Q" />
	<!--Import materialize.css-->
        <link rel="stylesheet" href="<?php echo base_url();?>assets/dropzone/demos.css">
        <script type="text/javascript" src="<?php echo base_url();?>assets/dropzone/dropzone.js"></script>
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/materialize.css"  media="screen,projection" type="text/css"/>
	
	<title><?php if(isset($title)) echo $title;?></title>
	<!--Let browser know website is optimized for mobile-->
	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<link rel="icon" href="<?php echo base_url();?>assets/Icon/favicon.png" type="image/png" sizes="16x16">

	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/seve.css">
	<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url();?>assets/js/materialize.js" type="text/javascript"></script>
	
</head>

<body>