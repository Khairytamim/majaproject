<div class="col s12 m9 l9 ">
	<h4 style="text-align: center; color: #e45d25; margin-bottom: 1em">
			 <b>BRANDS</b>
   </h4>
   
   <div class="row" style="margin-left:auto;margin-right:auto">	
   	<div class="col s6 l3"> <img src="<?php echo base_url();?>assets/img/logo_brand/prelaunch/brand1.png" style="height:150px; display:block; margin: 1em 0;"> </div>
	<div class="col s6 l3"> <img src="<?php echo base_url();?>assets/img/logo_brand/prelaunch/brand2.png" style="height:150px; display:block; margin: 1em 0;"> </div>
	<div class="col s6 l3"> <img src="<?php echo base_url();?>assets/img/logo_brand/prelaunch/brand3.png" style="height:150px; display:block; margin: 1em 0;"> </div>
	<div class="col s6 l3"> <img src="<?php echo base_url();?>assets/img/logo_brand/prelaunch/brand4.png" style="height:150px; display:block; margin: 1em 0;"> </div>
	<div class="col s6 l3"> <img src="<?php echo base_url();?>assets/img/logo_brand/prelaunch/brand5.png" style="height:150px; display:block; margin: 1em 0;"> </div>
	<div class="col s6 l3"> <img src="<?php echo base_url();?>assets/img/logo_brand/prelaunch/brand6.png" style="height:150px; display:block; margin: 1em 0;"> </div>
	<div class="col s6 l3"> <img src="<?php echo base_url();?>assets/img/logo_brand/prelaunch/brand7.png" style="height:150px; display:block; margin: 1em 0;"> </div>
	<div class="col s6 l3"> <img src="<?php echo base_url();?>assets/img/logo_brand/prelaunch/brand8.png" style="height:150px; display:block; margin: 1em 0;"> </div>
	<div class="col s6 l3"> <img src="<?php echo base_url();?>assets/img/logo_brand/prelaunch/1.png" style="height:150px; display:block; margin: 1em 0;"> </div>
	<div class="col s6 l3"> <img src="<?php echo base_url();?>assets/img/logo_brand/prelaunch/2.png" style="height:150px; display:block; margin: 1em 0;"> </div>
	<div class="col s6 l3"> <img src="<?php echo base_url();?>assets/img/logo_brand/prelaunch/3.png" style="height:150px; display:block; margin: 1em 0;"> </div>

   </div>
	<center>
          <ul class="pagination" style="margin-top: 3em">
	    <li class="disabled"><a href="#!"><i class="material-icons">chevron_left</i></a></li>
	    <li class="active" style="background-color:black"><a href="#!">1</a></li>
	    <li class="waves-effect"><a href="#!">2</a></li>
	    <li class="waves-effect"><a href="#!">3</a></li>
	    <li class="waves-effect"><a href="#!">4</a></li>
	    <li class="waves-effect"><a href="#!">5</a></li>
	    <li class="waves-effect"><a href="#!"><i class="material-icons">chevron_right</i></a></li>
	</ul></center>
</div>

   
</div>
</div>