<div class="col s9 panel-divider">

		<div class="row" style="margin-left:auto;margin-right:auto">
               		<p>TOTS</p>
               </div>
	</div>
</div>
</div>