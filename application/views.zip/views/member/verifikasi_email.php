<div class="container">
  <div class="row" style="margin-top:10px">
      <div class="row">
        <div class="col s12 l8">
         <img src="<?php echo base_url();?>assets/img/logo_seve/logo-01.png" style="width:100%"/>
        </div>
        <div class="col s12 l4">
          <div class="card">
            <div class="card-content">
            	<p><b>VERIFIKASI EMAIL MEMBER</b><br /></p>
                <span style="font-size:12px">Silahkan cek email anda!</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.min.js"></script> 
<script type="text/javascript" src="<?php echo base_url();?>assets/js/materialize.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('select').material_select();
  });
</script>
</body></html>