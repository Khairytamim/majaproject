 
  <div class="navbar-fixed">
        <nav style="background-color:#003a75">
            <div class="container">
                <div class="nav-wrapper">
                    <div class="left"><img src="<?php echo base_url();?>assets/img/admindistro1.png" height="45px" style="margin-top:10px;"></div>
                    <!--a href="daftaradmin" data-activates="mobile-demo" class="button-collapse right"><img style="margin-top:7px; width:40px" src="<?php echo base_url();?>assets/assets/menu.svg"></a-->
                    <a href="<?php echo base_url();?>adminDistro/logout" data-activates="mobile-demo" class="button-collapse right"><i class="material-icons left">input</i><b>LOGOUT</b>
                    <ul class="right hide-on-med-and-down">
                        <li><a href="<?php echo base_url();?>adminDistro/logout"><i class="material-icons left">input</i><b>LOGOUT</b></a></li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
  
  