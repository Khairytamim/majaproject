	<div class="col s12">
		<div class="navbar-fixed">
			<nav style="background-color:#00a5d6 ">
				<div class="nav-wrapper">
					<a href="#!" class="brand-logo">HOME</a>
				</div>
			</nav>
		</div>
	</div>