 
  <div class="navbar-fixed">
        <nav style="background-color:#003a75">
            <div class="container">
                <div class="nav-wrapper">
                    <div class="center brand-logo"><img src="<?php echo base_url();?>assets/img/logo_seve/logo.png" height="45px" style="margin-top:10px;"></div>

                </div>
            </div>
        </nav>
    </div>
  
  