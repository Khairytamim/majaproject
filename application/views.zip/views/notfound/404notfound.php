<html>
<head>
<title>SEVE | Cari dan Buat Gayamu.</title>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head>
<body style ="text-align:center; background-color:#003a75;">

<img src="<?php echo base_url();?>assets/img/fikry.png" width="1280px" height="545px">

</body>
</html>