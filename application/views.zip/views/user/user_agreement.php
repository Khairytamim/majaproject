<div class="container" align="justify" >

	<br><h4><u><b><center>USER AGREEMENT</center></b></u></h4><br>
	<p><b><center>INFORMASI UMUM</center></b><br>

	seveid.com sebagai sarana penunjang bisnis local brand fashion berusaha menyediakan
	
	berbagai fitur dan layanan untuk menjamin keamanan dan kenyamanan para penggunanya.
	
	seveid.com berperan sebagai perantara antara pihak local brand(store) dengan pembeli. untuk
	
	transaksi yang berlangsung di dalam platform ini bisa melalui mekanisme COD, via transfer,
	
	kartu kredit, paypal, dll. kami hanya mengambil 5% dari harga produk atau menambahkan 10%
	
	dari harga produk sebagai bagian dari kesepakatan kerja sama.<br><br>
	
	kami hanya mengizinkan jual beli barang berupa produk fashion lokal, sehingga barang impor
	
	dari luar negeri tidak diizinkan untuk dijual dalam platform kami.
	
	seveid.com tidak bertanggung jawab atas rusaknya reputasi pihak lain, dan/atau segala bentuk
	
	perselisihan yang dapat terjadi antar pengguna situs.<br><br>
	
	seveid.com memiliki kewenangan untuk mengambil tindakan yang dianggap perlu terhadap
	
	akun yang diduga dan/atau terindikasi melakukan penyalahgunaan, memanipulasi, dan/atau
	
	melanggar peraturan di seveid.com, maupun menutup akun tersebut tanpa memberikan
	
	pemberitahuan atau informasi terlebih dahulu kepada pemilik akun yang bersangkutan.
	
	Pengguna situs seveid.com wajib mengisi data secara lengkap dan jujur di halaman admin
	
	(profil).<br><br>
	
	Pengguna situs seveid.com bertanggung jawab atas keamanan dari akun termasuk
	
	penggunaan e­mail dan password.
	
	Pengguna situs seveid.com wajib mengisi data bank (bank account) untuk kepentingan
	
	bertransaksi di seveid.com.<br><br>
	
	Penggunaan fasilitas apapun yang disediakan oleh seveid.com mengindikasikan bahwa
	
	pengguna telah memahami dan menyetujui segala aturan yang diberlakukan oleh kami.
	
	Selama berada dalam wilayah situs seveid.com, pengguna dilarang keras menyampaikan
	
	setiap jenis konten apapun yang mengandung / bersinggungan dengan unsur SARA,
	
	diskriminasi, dan/atau menyudutkan pihak lain.<br><br>
	
	Pengguna juga tidak diperbolehkan untuk menggunakan situs ini untuk melanggar peraturan
	
	yang ditetapkan oleh hukum di Indonesia maupun di negara lainnya.
	
	Pengguna situs seveid.com bertanggung jawab atas segala resiko yang timbul di kemudian hari
	
	atas informasi yang diberikannya ke dalam situs ini, termasuk namun tidak terbatas pada
	
	hal­hal yang berkaitan dengan hak cipta, merek, desain industri, desain tata letak industri dan
	
	hak paten atas suatu produk.<br><br>
	
	Pengguna situs seveid.com diwajibkan menghargai hak­hak pengguna lainnya dengan tidak
	
	memberikan informasi pribadi ke pihak lain tanpa izin pihak yang bersangkutan.
	
	Pengguna situs seveid.com tidak diperkenankan mengirimkan e­mail spam dengan merujuk ke
	
	bagian apapun dari situs ini.<br><br>
	
	Administrator seveid.com berhak menyesuaikan dan menghapus informasi barang, bahkan
	
	menonaktifkan akun pengguna yang melanggar peraturan jual barang.
	
	seveid.com memiliki hak untuk memblokir penggunaan sistem terhadap pengguna situs yang
	
	melanggar peraturan dan ketetapan yang berlaku.<br><br>
	
	Pengguna situs seveid.com akan mendapatkan beragam informasi promo terbaru dan
	
	penawaran eksklusif. Namun, pengguna situs seveid.com dapat berhenti berlangganan
	
	(unsubscribe) jika tidak ingin menerima informasi tersebut.<br><br>
	
	<br><b><center>JUAL BARANG</center></b> <br>
	
	Pihak store bertanggung jawab secara penuh atas segala resiko yang timbul di kemudian hari
	
	terkait dengan informasi yang dibuatnya, termasuk, namun tidak terbatas pada hal­hal yang
	
	berkaitan dengan hak cipta, merek, desain industri, desain tata letak sirkuit, hak paten dan/atau
	
	izin lain yang telah ditetapkan atas suatu produk menurut hukum yang berlaku di Indonesia.
	
	Pihak store tidak diperbolehkan menjual barang­barang yang tidak tercantum di daftar “Barang
	
	Terlarang”.<br><br>
	
	Pihak store wajib menempatkan barang dagangan sesuai dengan kategori dan subkategorinya.
	
	Pihak store wajib mengisi nama barang/judul barang dengan jelas, singkat dan padat.
	
	Pihak store wajib menampilkan gambar barang yang sesuai dengan deskripsi barang yang
	
	dijual dan tidak mencantumkan logo ataupun alamat situs jual­beli lain pada gambar. Dianjurkan
	
	foto atau gambar memperlihatkan 3 bagian (depan, samping dan belakang) dengan resolusi
	
	minimal 500px.<br><br>
	
	Pihak store wajib mengisi harga yang sesuai dengan harga sebenarnya.
	
	Pihak store tidak diperkenankan mencantumkan alamat (situs, forum, & social network), nomor
	
	kontak, ID / PIN / username social media, dan nomor rekening bank selain pada kolom yang
	
	disediakan.<br><br>
	
	Pihak store dilarang memposting barang yang sudah pernah diposting sebelumnya (multiple
	
	posting)
	
	Pemberian informasi alamat (situs, forum, & social network), nomor telepon, ID / PIN /
	
	username social media tidak diperbolehkan.<br><br>
	
	Pihak store wajib memperbarui (update) ketersediaan dan status barang yang dijual.
	
	catatan tambahan yang tidak terkait dengan deskripsi barang kepada calon pembeli. Catatan
	
	Pihak store tetap tunduk terhadap Aturan Penggunaan seveid.com.
	
	Pihak store wajib mengirim barang pesanan menggunakan jasa pengiriman yang telah kami
	
	sediakan.<br><br>
	
	Pihak store dilarang membuat transaksi fiktif atau palsu demi kepentingan menaikkan feedback.
	
	Pihak seveid.com berhak mengambil tindakan seperti pemblokiran akun atau tindakan lainnya
	
	apabila ditemukan tindakan kecurangan.<br><br>
	
	<br><b><center>TRANSAKSI</center></b> <br>
	
	Setelah pembeli mentransfer sesuai dengan total belanja transaksi dalam waktu 1x12 jam
	
	(dengan asumsi pembeli telah mempelajari informasi barang yang telah dipesannya).
	
	Jika dalam waktu 1x12 jam barang dipesan, tetapi pembeli tidak mentransfer dana, maka
	
	transaksi akan dibatalkan secara otomatis.<br><br>
	
	Pembeli tidak dapat membatalkan transaksi setelah melunasi pembayaran.
	
	Setelah pembeli melunasi transaksi maka pihak seveid.com akan langsung mentransfer ke
	
	pihak store dalam kurun waktu 3 jam.
	
	Pihak store wajib melakukan konfirmasi “Dibayar” apabila telah menerima transfer dari
	
	seveid.com dalam kurun waktu 6 jam.
	
	Pihak store wajib mengirim barang dan mendaftarkan nomor resi pengiriman yang benar dan
	
	asli setelah status transaksi “Dibayar” maka store akan di berikan waktu 12 jam setelah
	
	melakukan konfirmasi pembayaran dari pihak seveid.com.<br><br>
	
	Jika pihak store tidak mengirimkan barang dalam batas waktu pengiriman sejak pembayaran
	
	(1x12 jam) pihak store dianggap telah menolak pesanan. Sehingga, sistem secara otomatis
	
	memberikan feedback negative, serta mengembalikan seluruh dana (refund) ke pembeli.
	
	Sistem Seveid.com secara otomatis mengecek status pengiriman barang melalui nomor resi
	
	yang diberikan pihak store . Seluruh dana akan dikembalikan ke pembeli apabila nomor resi
	
	terdeteksi tidak valid dan pihak store tidak melakukan ubah resi valid dalam 1x24jam. Jika pihak
	
	store memasukkan nomor resi tidak valid lebih dari satu kali maka Seveid.com akan
	
	mengembalikan seluruh dana transaksi kepada pembeli dan pihak store mendapatkan feedback
	
	negatif.<br><br>
	
	Jika pembeli tidak memberikan konfirmasi penerimaan barang dalam waktu 2 x 24 jam sejak
	
	barang diterima yang dinyatakan di sistem tracking jasa pengiriman, Seveid.com akan
	
	mengkonfirmasi penerimaan barang kepada store tanpa sepengetahuan pembeli.
	
	Sistem secara otomatis memberikan feedback (rekomendasi) positif dan mentransfer dana
	
	pembayaran kepada pihak store jika pembeli sudah melakukan transfer.
	
	Retur (pengembalian barang) hanya diperbolehkan jika kesalahan dilakukan oleh pihak store
	
	dan barang tidak sesuai deskripsi.<br><br>
	
	Retur tidak bisa dilakukan setelah transaksi selesai menurut general tracking Seveid.com atau
	
	dikonfirmasi transaksi selesai oleh pembeli.<br><br>
	
	<br><b><center>LANGKAH-LANGKAH MELAKKUKAN RETUR</center></b> <br>
	
	seveid.com akan melakukan kesepakatan (antara pembeli dan store) apakah akan dilakukan
	
	pengembalian barang ke store atau tidak.
	
	Selanjutnya, pembeli harus mengirim barang tersebut ke kantor seveid.com.
	
	kami tidak bertanggung jawab terhadap barang retur di kantor seveid.com apabila pihak store
	
	tidak melakukan pengaduan kepemilikan barang dalam waktu 30 hari sejak barang diterima di
	
	kantor seveid.com.<br><br>
	
	Pembeli harus mengirim barang ke pihak distro dan menginfokan nomor resi ke seveid.com jika
	
	ada kesepakatan pengembalian barang (retur) ke pihak distro.
	
	seveid.com hanya memantau retur sampai barang diterima kembali oleh pelapak.<br><br>
	
	<br><b><center>SANKSI</center></b> <br>
	
	Segala tindakan yang melanggar peraturan di Seveid.com akan dikenakan sanksi berupa:
	
	Feedback (rekomendasi) negatif. Pihak distro mendapatkan 1 feedback negatif apabila tidak
	
	mengirimkan barang dalam batas waktu pengiriman sejak pembayaran (4x24 jam untuk biaya
	
	pengiriman reguler atau 2x24 jam untuk biaya pengiriman kilat) atau jika sudah 5 kali menolak
	
	pesanan. Pihak distro dapat menghapus 1 feedback (rekomendasi) negatif setiap mendapat 20
	
	feedback (rekomendasi) positif dan kelipatannya.
	
	Akun dibekukan atau dinonaktifkan.
	
	Pelaporan ke pihak terkait (Kepolisian, dll).
	
	<br><br><b><center>PEMBATASAN TANGGUNG JAWAB</center></b> <br>
	 
	Seveid.com tidak bertanggung jawab atas segala resiko dan kerugian yang timbul dari dan
	
	dalam kaitannya dengan informasi yang dituliskan oleh pengguna Seveid.com.
	
	Seveid.com tidak bertanggung jawab atas segala pelanggaran hak cipta, merek, desain industri,
	
	desain tata letak sirkuit, hak paten atau hak­hak pribadi lain yang melekat atas suatu barang,
	
	berkenaan dengan segala informasi yang dibuat oleh Pihak store.<br><br>
	
	Seveid.com tidak bertanggung jawab atas segala resiko dan kerugian yang timbul berkenaan
	
	dengan penggunaan barang yang dibeli melalui Seveid.com, dalam hal terjadi pelanggaran
	
	ketentuan perundang­undangan<br><br>
	
	Seveid.com tidak bertanggung jawab atas segala resiko dan kerugian yang timbul berkenaan
	
	dengan peretasan terhadap akun pengguna yang dilakukan oleh pihak ketiga.
	
	Seveid.com tidak bertanggung jawab atas segala resiko dan kerugian yang timbul apabila
	
	transaksi telah dianggap selesai (uang transaksi telah masuk ke Pihak store ataupun Pembeli).
	
	Seveid.com tidak bertanggung jawab atas segala resiko dan kerugian yang timbul akibat
	
	kehilangan barang di jasa pengiriman barang ketika proses transaksi berjalan dan/atau selesai.<br><br></p>
	
	<form action="<?php echo base_url();?>verifikasi/authentication_toko/<?php echo $auth;?>" method="post">
          <input type="hidden" value="<?php echo $auth;?>"/>
          <button type="submit" class="waves-effect waves-light btn" style="width:100%; margin-top:20px; margin-bottom:20px; background-color:#385678">SETUJU</button>
          </div>
        </form>
        
</div>


        